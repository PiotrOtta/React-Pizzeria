const pizzaAddons = [
    {
        id: 1,
        name: "pieczarki",
        price: 2.50
    },
    {
        id: 2,
        name: "mozzarella",
        price: 2.50
    },
    {
        id: 3,
        name: "szynka",
        price: 2.50
    },
    {
        id: 4,
        name: "boczek",
        price: 2.50
    },
    {
        id: 5,
        name: "ser",
        price: 2.50
    },
    {
        id: 6,
        name: "salami",
        price: 2.50
    },
    {
        id: 7,
        name: "cebula",
        price: 2.50
    },
    {
        id: 8,
        name: "sos pomidorowy",
        price: 2.50
    },
    {
        id: 9,
        name: "sos czosnkowy",
        price: 2.50
    },
    {
        id: 10,
        name: "sos ostry",
        price: 2.50
    },
    {
        id: 11,
        name: "sos musztardowy",
        price: 2.50
    }
]

export default pizzaAddons